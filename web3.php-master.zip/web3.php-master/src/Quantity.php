<?php

namespace Web3;

class Quantity
{
 const latest ='latest';
 const earliest ='earliest';
 const pending ='pending';
}